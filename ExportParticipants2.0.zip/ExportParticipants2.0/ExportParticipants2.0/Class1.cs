﻿using System;

namespace ExportParticipants2._0
{
    public class Class1
    {
    }
}
