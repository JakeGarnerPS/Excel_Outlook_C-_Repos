/*          
 *          
|--------- Server Ping Executable -------------------|
|--------- Internal Deloitte Program ----------------|
|--------- Creator: Jake Garner ---------------------|
|--------- Version: 2.5 -----------------------------|
|--------- Inital Draft 18/01/2019 ------------------|
|--------- Awaiting review 12/02/2019 ---------------|
|----------------------------------------------------|
|------------------ CHANGES -------------------------|
|  Added the server info which holds all VDI names   |
|                                                    |
|                                                    |
|                                                    |
|                                                    |
|----------------------------------------------------|
*
*/

#region Librays
//General
using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
//Sql
using System.Data.SqlClient;
using System.Collections;
//Outlook
using Outlook = Microsoft.Office.Interop.Outlook;
//Xml
using System.Xml;
//Exceptions
using Exception = System.Exception;
using System.IO;

#endregion


namespace ServerPingingVersion1._0
{

    /// Class that holds variables that are used in multiple classes 
    class Variables
    {

        public static bool connection;

        public static SqlConnection cnn;
        public static string connectionServer;
        public static string connectionDatabase;

        public static string sendToEmailAddress;
        public static string ccEmailAddress;

        public static string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

        public static string runType;

        public static int successfullPings;
        public static int failedPings;
        public static int errorPings;
        public static int totalPings;

    }
    /// Class that hold arrays that are used in multiple classes 
    class CollectionArray
    {

        public static List<string> failedAddress = new List<string>();
        public static List<string> addressList = new List<string>();
        public static ArrayList pingStatus = new ArrayList();
        public static List<string> errorMessages = new List<string>();

    }
    //-------- MAIN -----------  
    /// Runs the main code by calling the 'MethodCalls' class         
    class Program
    {
        private const int loop = 0;

        static void Main(string[] args)
        {
            ///set variables based on if process is in test mode or live
            TestingMode testing = new TestingMode();
            testing.Testing();

            Console.WriteLine("\nStarting Loop " + DateTime.Now.ToString());
            Console.WriteLine("\n--- " + Variables.userName + " || " + Variables.connectionServer + " ---");

            //Infinate loop 
            while (loop < 1)
            {

                if (Variables.runType == "Test Mode")
                {
                    ConsoleKeyInfo cki;
                    Console.WriteLine("\nPress 'F' to start");
                    cki = Console.ReadKey();
                    if (cki.Key == ConsoleKey.F)
                    {
                        //Calls the MethodCalls class that contains the other methods that need to run in order
                        MethodCalls testMode = new MethodCalls();
                        testMode.Methods();
                    }
                }

                else if (DateTime.Now.ToString("mm") == "30" || DateTime.Now.ToString("mm") == "00")
                {
                    //Calls the MethodCalls class that contains the other methods that need to run in order
                    MethodCalls methodCalls = new MethodCalls();
                    methodCalls.Methods();
                }
            }
        }
    }
    //-------- MAIN -----------
    /// If the user name of the machine is the same as the developer then put it in test mode
    class TestingMode
    {
        public void Testing()
        {

            if (Variables.userName.Contains("jakerobertgarner"))
            {
                Console.WriteLine("In Test Mode!\n");
                Variables.sendToEmailAddress = "jakerobertgarner@deloitte.co.uk";
                Variables.connectionServer = @"UKVIR10343\SQLEXPRESS";
                Variables.connectionDatabase = @"SupportDashboard";
                Variables.runType = "Test Mode";
            }
            ///If new VM/VDI need to be added to the list, just need to add another else if and set up the variables 
            else
            {
                Console.WriteLine("Running Live!\n");
                Variables.sendToEmailAddress = "";
                Variables.connectionServer = @"UKVIR10343\SQLEXPRESS";
                Variables.connectionDatabase = @"SupportDashboard";
                Variables.ccEmailAddress = "";
            }
        }
    }
    /// Method call stored here due to auto switching between test and live running, this is the main bulk of method calls
    class MethodCalls
    {
        public void Methods()
        {
            try
            {
                #region Method Calls 
                //SQL Connection
                SQLConnection connectionStatus = new SQLConnection();
                connectionStatus.Connections();
                ///Try and connect to SQL server and database

                //Use SQL or XML Data
                SqlORXml data = new SqlORXml();
                data.DataInput();
                ///Checks the whether the SQL connection was successful. 
                ///If it was then it will read the data off of the SQL table and update the XML file
                ///If the SQL connection fails then it will read the data off of the XML file

                //Ping Servers
                CommencePings ping = new CommencePings();
                ping.SendPing();
                ///Once the Data has been read then pings can commence

                //Email on Ping Failure 
                if (CollectionArray.pingStatus.Contains("Fail"))
                {
                    Email mail = new Email();
                    mail.SendMail();
                }
                ///If any of the pings fail then a email is sent out 
                ///This email shows which servers failed the ping test
                #endregion

            }
            catch (Exception ex)
            {
                CollectionArray.errorMessages.Add(ex.Message.ToString());
            }
            finally
            {

                Variables.totalPings = Variables.successfullPings + Variables.failedPings + Variables.errorPings;
                Console.WriteLine("\nTotal Number of Pings = " + Variables.totalPings + "\nTotal Successful Pings = " + Variables.successfullPings
                   + "\nTotal Failed Pings = " + Variables.failedPings + "\nTotal Errored Pings = " + Variables.errorPings + "\n" + "\n------------ Ping Testing Complete! ------------\n");

                //Email Creator on Error
                EmailCreatorOnError email = new EmailCreatorOnError();
                email.EmailOnError();
                ///Any exceptions, store them in array(could be more than one) then email them to developer

                //Clear Values 
                ClearValues cValues = new ClearValues();
                cValues.Clear();
                ///Once it has run through what is needed, the arrays and some variables are emptyed
                ///Mainly for the arrays as its an infinite loop if not cleared they would hold all values causing problems

            }
        }
    }
    /// Setup and connect to sql 
    class SQLConnection
    {

        public void Connections()
        {
            Console.WriteLine("\nUpdating Pings " + DateTime.Now.ToString());

            string connectionString = @"Data Source=" + Variables.connectionServer + @";Initial Catalog=" + Variables.connectionDatabase + @";Integrated Security =True";
            Variables.cnn = new SqlConnection(connectionString);

            try
            {
                Variables.cnn.Open();
                Console.WriteLine("Connected");
                Variables.connection = true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Failed to connect to SQL");
                Console.WriteLine(ex);
                Variables.connection = false;
                CollectionArray.errorMessages.Add(ex.Message.ToString() + "Failed to connect to SQL, inform team ASAP!");
            }
        }
    }
    /// If sql connection was a success then read sql data and update xml file || otherwise use xml file
    class SqlORXml
    {

        public void DataInput()
        {
            try
            {

                Variables.userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                string[] usernameSplit = Variables.userName.Split('\\');
                string xmlFileLocation = @"C:\Users\" + usernameSplit[1] + @"\Desktop\serverNames.xml";
                ///Use the username, split it to remove 'UK\' and use the value for file location

                if (Variables.connection == true)
                {
                    #region Read from SQL update XML file
                    SqlCommand command;
                    try
                    {

                        string select = $"SELECT DISTINCT [VDIName] FROM[UKVIR10343\\SQLEXPRESS].[SupportDashboard].[CFG].[VMDetails] ";
                        command = new SqlCommand(select, Variables.cnn);

                        SqlDataReader dataReader = command.ExecuteReader();

                        while (dataReader.Read())
                        {
                            CollectionArray.addressList.Add(Convert.ToString(dataReader[0].ToString()));

                        }
                        ///Run the sql query and add each value of the query to adressList array 
                        File.Delete(xmlFileLocation);
                        XmlWriter xmlWriter = XmlWriter.Create(xmlFileLocation);
                        xmlWriter.WriteStartDocument();
                        xmlWriter.WriteStartElement("Servers");
                        foreach (string p in CollectionArray.addressList)
                        {
                            xmlWriter.WriteStartElement("Server");
                            xmlWriter.WriteString(p + "^");
                        }
                        xmlWriter.WriteEndDocument();
                        xmlWriter.Close();
                        ///With the values in address list, update the xml file and use '^' as the delimeter
                    }
                    catch (Exception ex)
                    {
                        CollectionArray.errorMessages.Add(ex.Message.ToString() + Variables.connection);
                        Variables.connection = false;
                        SqlORXml selectFailed = new SqlORXml();
                        selectFailed.DataInput();
                    }
                    finally
                    {
                        Variables.cnn.Close();
                        ///Always close connection even if it was successful
                    }
                    #endregion
                }

                #region Read from XML

                else if (Variables.connection == false)
                {
                    Console.WriteLine("\n Using XML values \n");
                    string xmlFileName = @"C:\Users\" + usernameSplit[1] + @"\Desktop\serverNames.xml";
                    XmlDocument doc = new XmlDocument();
                    doc.Load(xmlFileName);


                    //foreach (XmlNode node in doc.DocumentElement.SelectSingleNode("/Servers"))
                    foreach (XmlNode node in doc.DocumentElement.ChildNodes)
                    {

                        string name = node.InnerText;
                        if (name != null)
                        {
                            string[] splitNode = name.Split('^');
                            foreach (string s in splitNode)
                            {
                                s.Trim();
                                Console.WriteLine(s);
                                CollectionArray.addressList.Add(s);
                            }

                            System.Threading.Thread.Sleep(1000);

                        }
                        else
                        { CollectionArray.errorMessages.Add("XML files contains no values !"); }

                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                CollectionArray.errorMessages.Add(ex.Message.ToString() + Variables.connection);
            }
        }
    }
    /// Start ping servers from data source 
    class CommencePings
    {

        public void SendPing()
        {
            Console.WriteLine("\n---------------------------------------------");
            foreach (string i in CollectionArray.addressList)
            {
                try
                {

                    Ping myPing = new Ping();

                    PingReply reply = myPing.Send(( i.Trim() ), 1000);
                    if (reply != null)
                    {
                        Console.WriteLine("Server Name: " + i);
                        Console.WriteLine("\nStatus: " + reply.Status + "\nTime: " + reply.RoundtripTime.ToString() + "\nIPV4 Address: " + reply.Address);
                        Console.WriteLine("\n---------------------------------------------");
                        ///creates the pings and displays the status, time taken and address of the ping
                        if (reply.Status == IPStatus.TimedOut || reply.Status == IPStatus.TimeExceeded)
                        {
                            CollectionArray.pingStatus.Add("Fail");
                            CollectionArray.failedAddress.Add(i);
                            Variables.failedPings = Variables.failedPings + 1;
                        }
                        else
                        {
                            CollectionArray.pingStatus.Add("Pass");
                            Variables.successfullPings = Variables.successfullPings + 1;
                        }
                        ///if ping times out or passes the max time then it is marked as a fail
                        ///this is not an exception as this means the address is correct, but it is not availible
                    }
                }
                catch (PingException ex)
                {
                    ///if there is an error then the exception is caught and marked as a fail, also email is sent to developer to inform them of error
                    CollectionArray.pingStatus.Add("Fail");
                    CollectionArray.failedAddress.Add(i);
                    CollectionArray.errorMessages.Add(ex.Message.ToString() + ": " + i + " || Likley to be server name containing a typo, or server does not exist");
                    Variables.errorPings = Variables.errorPings + 1;
                }

            }
            foreach (string j in CollectionArray.failedAddress)
            {
                Console.WriteLine("\nFailed to ping address: " + j);
            }
        }
    }
    /// If server ping fails, send email
    class Email
    {
        private readonly string subjectLine = "Server Connection Problem!";

        public void SendMail()
        {
            try
            {
                /// Creates the body of the email with a table using HTML
                /// Dont know HTLM well, so this will be messy
                #region Email body setup with HTML

                string bodyText = "Hi all, <br />"
                    + "<br/>The following SERVERS have failed the ping test, please check connections <br />";
                ///Text in email

                string tableStyle = "<style type=\"text/css\" media=\"all\">table{border: 2px Solid Green; font face=\"verdana\";} " +
                    "th, td{border-collapse: collapse; border: 1px Solid Black; text-align: left;}" +
                    "th{background-color: Black; color: white; padding: 5px;}" +
                    "td{font-size = 0; color: black; padding: 5px}" +
                    "tr{font-size = 0; line-height:0px; border-collapse: collapse; }";
                ///Styling the table

                string bodynew = "<table style=\"width:70%\">" +
                    "<tr><th><font face=\"verdana\">Server Name</font></th>" +
                    "<th><font face=\"verdana\">Server Status</font></th>" +
                    "<th><font face=\"verdana\">Time of Ping</font></th></tr> ";
                ///More table styling, Creating the Header names and font type

                foreach (string messageBody in CollectionArray.failedAddress)
                {
                    bodynew = bodynew + "<tr><td><font face=\"verdana\">" + messageBody
                        + "</font></td>" + "<td bgcolor=\"#FA2C2C\"><font face=\"verdana\">" + "Failed" + "</font></td>"
                        + "<td><font face=\"verdana\">" + DateTime.Now.ToString() + "</font></td></tr>";
                    ///Setting up how each row will be displayed in the table
                }

                string signature = "<font size=\"2\"; font face=\"Verdana\"><br /><br /><b>DMS RPA Support Team</b>"
                    + "<br />RPA Support | Risk Advisory | DMS"
                    + "<br />Deloitte LLP"
                    + "<br /><a href=\"UKDMSRPASupport@deloitte.co.uk\">UKDMSRPASupport@deloitte.co.uk</a>" + " | " + " <a href=\"www.deloitte.co.uk\">www.deloitte.co.uk</a> </font>";
                ///Add the RPA teams signiture to the end of the email
                ///
                bodynew = "<font face=\"verdana\">" + bodyText + "</font><br />" + tableStyle + bodynew + "</table>" + signature;

                #endregion  

                Outlook.Application app = new Outlook.Application();
                Outlook.NameSpace NS = app.GetNamespace("MAPI");
                Outlook.MAPIFolder objFolder = NS.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderOutbox);
                Outlook.MailItem objMail = app.CreateItem(Outlook.OlItemType.olMailItem);
                objMail.BodyFormat = Outlook.OlBodyFormat.olFormatHTML;
                objMail.HTMLBody = bodynew;
                objMail.Subject = subjectLine;
                objMail.To = Variables.sendToEmailAddress;
                objMail.CC = Variables.ccEmailAddress;
                ///Email setup

                if (Variables.runType == "Test Mode")
                {
                    ConsoleKeyInfo cki;
                    Console.WriteLine("\n----------------------------------------------------------------");
                    Console.WriteLine("\nPress 'S' to display email or 'Q' to skip");
                    cki = Console.ReadKey();

                    if (cki.Key == ConsoleKey.S)
                    {
                        objMail.Display();
                    }
                    else if (cki.Key == ConsoleKey.Q)
                    {

                    }
                }
                else
                {
                    objMail.Send();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to send email ", ex.Message);
                CollectionArray.errorMessages.Add(ex.Message.ToString() + " Failed to send email");
            }
        }
    }
    /// If there is a exception then email the dev to fix       
    class EmailCreatorOnError
    {

        private readonly string creatorEmail = "jakerobertgarner@deloitte.co.uk";
        private readonly string creatorSubject = "RPA PING ROBOT EXEPTIONS!";
        private string errorList;

        public void EmailOnError()
        {
            try
            {

                if (CollectionArray.errorMessages != null)
                {
                    foreach (string z in CollectionArray.errorMessages)
                    {
                        errorList = errorList + z + "<br />";
                    }
                    string bodynew = "The following error/s occured, please check and fix the issue/s......... <br /> " + errorList;
                    Outlook.Application app = new Outlook.Application();
                    Outlook.NameSpace NS = app.GetNamespace("MAPI");
                    Outlook.MAPIFolder objFolder = NS.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderOutbox);
                    Outlook.MailItem objMail = (Outlook.MailItem)objFolder.Items.Add(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                    objMail.BodyFormat = Outlook.OlBodyFormat.olFormatHTML;
                    objMail.HTMLBody = bodynew;
                    objMail.Subject = creatorSubject;
                    objMail.To = creatorEmail;

                    if (Variables.runType == "Test Mode")
                    {
                        ConsoleKeyInfo cki;
                        Console.WriteLine("\n----------------------------------------------------------------");
                        Console.WriteLine("\nPress 'S' to send error email to developer or press 'Q' to skip");
                        cki = Console.ReadKey();

                        if (cki.Key == ConsoleKey.S)
                        {
                            Console.WriteLine("\nErrors / Exceptions occured, emailing developer!");
                            objMail.Send();
                        }
                        else if (cki.Key == ConsoleKey.Q)
                        {
                            Console.WriteLine("\n WARNING! Errors/Exceptions Occured!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nErrors / Exceptions occured, emailing developer!");
                        objMail.Send();
                    }
                }
                else
                {
                    Console.WriteLine("\nNo Errors / Exceptions occured");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to send email ", ex.Message);
            }
        }
    }
    /// Clears variable/array values, otherwise arrays would get full of repeting data and casue issues, aslo gives stats of pings
    class ClearValues
    {

        public void Clear()
        {
            try
            {
                #region Clear values
                CollectionArray.addressList.Clear();
                CollectionArray.failedAddress.Clear();
                CollectionArray.pingStatus.Clear();
                CollectionArray.errorMessages.Clear();
                Variables.successfullPings = 0;
                Variables.errorPings = 0;
                Variables.failedPings = 0;
                Variables.totalPings = 0;
                Console.WriteLine("\nAll values cleared\n");
                #endregion
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to clear variables ", ex.Message);
                CollectionArray.errorMessages.Add(ex.Message.ToString() + "Failed to Clear Varibales");
            }
        }
    }
}